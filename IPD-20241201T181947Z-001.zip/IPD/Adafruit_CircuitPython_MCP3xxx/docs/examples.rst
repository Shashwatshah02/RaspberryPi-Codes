Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/mcp3xxx_mcp3008_single_ended_simpletest.py
    :caption: examples/mcp3xxx_mcp3008_single_ended_simpletest.py
    :linenos:

.. literalinclude:: ../examples/mcp3xxx_mcp3004_single_ended_simpletest.py
    :caption: examples/mcp3xxx_mcp3004_single_ended_simpletest.py
    :linenos:

.. literalinclude:: ../examples/mcp3xxx_mcp3002_single_ended_simpletest.py
    :caption: examples/mcp3xxx_mcp3002_single_ended_simpletest.py
    :linenos:

.. literalinclude:: ../examples/mcp3xxx_mcp3008_differential_simpletest.py
    :caption: examples/mcp3xxx_mcp3008_differential_simpletest.py
    :linenos:

.. literalinclude:: ../examples/mcp3xxx_mcp3004_differential_simpletest.py
    :caption: examples/mcp3xxx_mcp3004_differential_simpletest.py
    :linenos:

.. literalinclude:: ../examples/mcp3xxx_mcp3002_differential_simpletest.py
    :caption: examples/mcp3xxx_mcp3002_differential_simpletest.py
    :linenos:
