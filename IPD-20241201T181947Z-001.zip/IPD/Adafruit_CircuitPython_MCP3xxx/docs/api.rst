API
------------

.. automodule:: adafruit_mcp3xxx.mcp3xxx
    :members:

.. automodule:: adafruit_mcp3xxx.analog_in
    :members:

.. automodule:: adafruit_mcp3xxx.mcp3008
    :members:
    :show-inheritance:

.. automodule:: adafruit_mcp3xxx.mcp3004
    :members:
    :show-inheritance:

.. automodule:: adafruit_mcp3xxx.mcp3002
    :members:
    :exclude-members: read
    :show-inheritance:
