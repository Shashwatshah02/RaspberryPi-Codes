from twilio.rest import Client

account_sid = 'AC78fec64218509a793241d1a18d6b1a98'
auth_token = 'dae1d019406675166fdc7d11a672a333'
client = Client(account_sid, auth_token)

message = client.messages.create(
  from_='+12184026613',
  to='+919820077642',
  body= "Test SMS",
)

print(message.sid)